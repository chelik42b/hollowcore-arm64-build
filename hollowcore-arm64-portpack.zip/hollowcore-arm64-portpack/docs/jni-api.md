# EffekseerNativeForJava — полный JNI API (извлечено из HollowCore)

Источник: `src/main/java/Effekseer/swig/EffekseerCoreJNI.java` (SWIG 4.1.1, автогенерация).
Это native-методы, которые Java/Kotlin код HollowCore вызывает напрямую. Их 66 (без учёта
delete_*/new_* — они тоже входят в список ниже).

Классы-обёртки, которые их используют:
- `EffekseerBackendCore` — инициализация GL-бекенда, устройство, Terminate
- `EffekseerEffectCore` — загрузка .efk/.efkefc, текстур, моделей, материалов, кривых
- `EffekseerManagerCore` — сцена: Play/Stop/Update, трансформации, камера, слои, draw calls

## Загрузка библиотеки
`ru.hollowhorizon.hc.client.render.effekseer.EffekseerNatives` (Kotlin enum):
- имя файла всегда `EffekseerNativeForJava` + расширение по ОС (`.so` для `Util.OS.LINUX`)
- **Android/PojavLauncher/ZalithLauncher репортит `Util.OS.LINUX`**, отдельной ветки ARM/x86
  в коде нет — то есть различение архитектур в Java-коде отсутствует и не требуется.
- Загрузка через `System.load(canonicalPath)` (не `loadLibrary`), файл предварительно
  копируется из ресурса `natives/EffekseerNativeForJava.<ext>` в
  `<gamedir>/hollowcore/natives/`.

**Вывод: Java/Kotlin код менять не нужно.** Проблема на 100% в одном бинарном файле —
достаточно положить arm64-v8a `.so` под тем же именем `EffekseerNativeForJava.so`.

## Полный список native-методов (77 сигнатур)

```
new_EffekseerBackendCore()
delete_EffekseerBackendCore(long)
EffekseerBackendCore_GetDevice()
EffekseerBackendCore_InitializeWithOpenGL()
EffekseerBackendCore_Terminate()

new_EffekseerEffectCore()
delete_EffekseerEffectCore(long)
EffekseerEffectCore_Load(long, EffekseerEffectCore, byte[], int, float)
EffekseerEffectCore_GetTexturePath/Count/LoadTexture/HasTextureLoaded
EffekseerEffectCore_GetModelPath/Count/LoadModel/HasModelLoaded
EffekseerEffectCore_GetMaterialPath/Count/LoadMaterial/HasMaterialLoaded
EffekseerEffectCore_GetCurvePath/Count/LoadCurve/HasCurveLoaded
EffekseerEffectCore_GetTermMax/GetTermMin

new_EffekseerManagerCore()
delete_EffekseerManagerCore(long)
EffekseerManagerCore_Initialize__SWIG_0/1
EffekseerManagerCore_Update/BeginUpdate/EndUpdate/UpdateHandleToMoveToFrame
EffekseerManagerCore_Play/StopAllEffects/Stop/SetPaused/SetShown/SendTrigger
EffekseerManagerCore_SetEffectPosition/Rotation/Scale
EffekseerManagerCore_SetLayerParameter
EffekseerManagerCore_SetEffectTransformMatrix/SetEffectTransformBaseMatrix
EffekseerManagerCore_DrawBack__SWIG_0/1, DrawFront__SWIG_0/1
EffekseerManagerCore_SetLayer/SetCameraParameter
EffekseerManagerCore_SetProjectionMatrix/SetCameraMatrix
EffekseerManagerCore_Exists/SetViewProjectionMatrixWithSimpleWindow
EffekseerManagerCore_SetDynamicInput/GetDynamicInput
EffekseerManagerCore_LaunchWorkerThreads
EffekseerManagerCore_SetBackground/UnsetBackground/SetDepth/UnsetDepth
EffekseerManagerCore_GetInstanceCount/GetTotalInstanceCount
```

(Полные сигнатуры с типами — см. оригинальный
`src/main/java/Effekseer/swig/EffekseerCoreJNI.java` в исходниках HollowCore.)

## Откуда берётся эта библиотека на самом деле

Это НЕ проприетарная закрытая библиотека HollowCore. Это официальный биндинг:

**https://github.com/effekseer/EffekseerForMultiLanguages**

- Официальный проект команды Effekseer, генерирует SWIG-обёртки для C#/Java/Python
  поверх `git submodule` на движок **effekseer/Effekseer** (сам движок эффектов, C++).
- Требования по README: git, python, cmake ≥3.15, SWIG, JDK, ant.
- Сборка: `git submodule update --init`, затем `generate_swig_wrapper.sh`, затем
  `cmake -B build -S .`
- Java-класс `EffekseerCoreJNI.java`, который лежит в HollowCore, — это 1:1 файл,
  сгенерированный этим же проектом тем же SWIG 4.1.1 (видно по шапке файла и стилю
  сигнатур `jarg1_`). Значит, если пересобрать `EffekseerForMultiLanguages` для
  `arm64-v8a`, JNI-символы и Java API совпадут автоматически — писать JNI-обвязку
  вручную с нуля не требуется и не нужно (и я не стал бы гарантировать корректность
  такой "реимплементации с нуля" — движок Effekseer это десятки тысяч строк C++,
  включая парсер бинарного формата `.efk`, систему материалов/кривых и т.д. — переписать
  это "с нуля" за один проход и без возможности собрать/протестировать было бы
  безответственно выдавать за рабочий результат).
